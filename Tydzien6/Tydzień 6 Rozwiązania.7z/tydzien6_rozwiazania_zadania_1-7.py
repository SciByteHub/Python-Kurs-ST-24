'''
Plik z rozwiązaniami zadań z zestawu na kursie z tygodnia 6 - wprowadzenie do programowania obiektowego
Opracował: Jakub Susoł
'''
import pandas as pd
import numpy as np


########################################################################################################################
##                                                     Zadanie 1                                                      ##
########################################################################################################################

# Definiujemy funkcję przyjmującą zestaw danych w DataFrame, nazwe kolumny ceny i nazwe kolumny z przedmiotami
def wybierz_po_najnizszej_cenie(dataframe, nazwa_kolumny_ceny, nazwa_kolumny_przedmiotow):
    # Znajdujemy minimalną wartość w kolumnie cena
    minimalna_cena = min(dataframe[nazwa_kolumny_ceny])
    # definiujemy pustą zmienną do przechowywania tytułu gry
    najtanszy_przedmiot = None
    # Dla każdego indeksu w przedziale od 0 do długości zestawu danych
    for indeks in range(len(dataframe)):
        # Jeśli cena w danej lokalizacji indeks jest równa minimalnej cenie
        if dataframe[nazwa_kolumny_ceny][indeks] == minimalna_cena:
            # Zapisz tytuł przedmiotu o najniższej cenie
            najtanszy_przedmiot = dataframe[nazwa_kolumny_przedmiotow][indeks]
    print(f"Najtańsze {najtanszy_przedmiot} o cenie {minimalna_cena} zł")


# Punkt wejścia programu:
if __name__ == "__main__":
    # ładujemy dane tylko w trakcie wykonywania programu ze skryptu macierzystego
    dane = pd.read_excel("./ceny_gier.xlsx")
    # wypisujemy zwróconą przez funkcję wartość
    wybierz_po_najnizszej_cenie(dane, 'cena', 'gra')


########################################################################################################################
##                                                    Zadanie 2;3;4                                                   ##
########################################################################################################################

# Definiujemy klasę Człowiek
class Czlowiek:
    # Zadanie 2 - tworzymy inicjator klasy
    def __init__(self, imie, nazwizko, wiek, wzrost, waga):
        self.imie = imie
        self.nazwisko = nazwizko
        self.wiek = wiek
        self.wzrost = wzrost
        self.waga = waga

    ## Zadanie 4 - metoda "idź do sklepu"
    def idz_do_sklepu(self):
        print(f"{self.imie} idzie do sklepu.")

    ## Zadanie 4 - metoda "kup po najniższej cenie"
    def kup_po_najnizszej_cenie(self, dataframe, nazwa_kolumny_ceny, nazwa_kolumny_przedmiotow):
        # Znajdujemy minimalną wartość w kolumnie cena
        minimalna_cena = min(dataframe[nazwa_kolumny_ceny])
        # definiujemy pustą zmienną do przechowywania tytułu gry
        najtanszy_przedmiot = None
        # Dla każdego indeksu w przedziale od 0 do długości zestawu danych
        for indeks in range(len(dataframe)):
            # Jeśli cena w danej lokalizacji indeks jest równa minimalnej cenie
            if dataframe[nazwa_kolumny_ceny][indeks] == minimalna_cena:
                # Zapisz tytuł przedmiotu o najniższej cenie
                najtanszy_przedmiot = dataframe[nazwa_kolumny_przedmiotow][indeks]
        # wyświetl odpowiednie dane
        print(f"{self.imie} kupuje {najtanszy_przedmiot} za {minimalna_cena} zł")


# Punkt wejścia programu:
if __name__ == '__main__':
    # ładujemy dane tylko w trakcie wykonywania programu ze skryptu macierzystego
    dane = pd.read_excel("./ceny_gier.xlsx")

    ## Zadanie 3 - definicja obiektów i print ich parametrów
    # definiujemy obiekty Seba i Jula
    seba = Czlowiek("Seba", "Nietuzinkowski", 23, 180, 75)
    jula = Czlowiek("Jula", "Wiedźma", 20, 172, 67)

    # wypisywanie słowników parametrów obiektów za pomocą wbudowanej funkcji vars(obiekt)
    print(f"Obiekt Seba: {vars(seba)}")
    print(f"Obiekt Jula: {vars(jula)}")

    ## Zadanie 4 - metody idź do sklepu i kup po najniższej cenie, przykład na obiekcie Jula
    jula.idz_do_sklepu()
    jula.kup_po_najnizszej_cenie(dane, 'cena', 'gra')


########################################################################################################################
##                                                    Zadanie 5;6                                                     ##
########################################################################################################################

# Definiujemy klasę Kalkulator
class Kalkulator:
    # Definiujemy inicjator klasy
    def __init__(self, NUM_MAT1, NUM_MAT2):
        self.num_mat1 = NUM_MAT1
        self.num_mat2 = NUM_MAT2

    def dodawanie(self):
        return f"Dodawanie: {self.num_mat1} + {self.num_mat2} = {self.num_mat1 + self.num_mat2}\n"

    def odejmowanie(self):
        return f"Odejmowanie: {self.num_mat1} - {self.num_mat2} = {self.num_mat1 - self.num_mat2}\n"

    def mnozenie(self):
        return f"Mnożenie: {self.num_mat1} * {self.num_mat2} = {self.num_mat1 * self.num_mat2}\n"

    def dzielenie(self):
        try:
            if self.num_mat2 != 0:
                return f"Dzielenie: {self.num_mat1} / {self.num_mat2} = {self.num_mat1 / self.num_mat2}\n"
            else:
                raise ZeroDivisionError
        except ZeroDivisionError:
            return "Dzielnik wynosi zero, nie można wykonać operacji.\n"

    def potegowanie(self):
        return f"{self.num_mat1} ** {self.num_mat2} = {self.num_mat1 ** self.num_mat2}\n"

    # Pierwiastkowanie można wykonać potęgowaniem przez odwrotność stopnia pierwiastka
    def pierwiastkowanie(self):
        try:
            if self.num_mat2 != 0:
                return f"Pierwiastkowanie: {self.num_mat1} ** (1/{self.num_mat2}) = {self.num_mat1 ** (1 / self.num_mat2)}\n"
            else:
                raise ValueError
        except ValueError:
            return "Nie można pierwiastkować w stopniu 0\n"

    def mnozenie_macierzy(self):
        return f"MNOŻENIE\n\n{self.num_mat1}\nMNOŻONA PRZEZ\n{self.num_mat2}\nWYNOSI\n{np.dot(self.num_mat1, self.num_mat2)}\n"

    def dodawanie_macierzy(self):
        return f"DODAWANIE\n\n{self.num_mat1}\nPLUS\n{self.num_mat2}\nWYNOSI\n{self.num_mat1 + self.num_mat2}\n"

    def odejmowanie_macierzy(self):
        return f"ODEJMOWANIE\n\n{self.num_mat1}\nMINUS\n{self.num_mat2}\nWYNOSI\n{self.num_mat1 - self.num_mat2}\n"

    def dzielenie_macierzy(self):
        # Wyłączamy informacje o napotkaniu 0, NumPy automatycznie przypisuje inf do wyników dzielenie przez 0
        np.seterr(divide='ignore')
        return f"DZIELENIE\n\n{self.num_mat1}\nDZIELONA PRZEZ\n{self.num_mat2}\nWYNOSI\n{self.num_mat1 / self.num_mat2}\n"

    def transpozycja_pierwszej_macierzy(self):
        return f"TRANSPOZYCJA\n{self.num_mat1}\nWYNOSI\n{np.transpose(self.num_mat1)}\n"

    def transpozycja_drugiej_macierzy(self):
        return f"TRANSPOZYCJA\n{self.num_mat2}\nWYNOSI\n{np.transpose(self.num_mat2)}\n"


# Punkt wejścia programu:
if __name__ == "__main__":
    a = Kalkulator(5, 3)
    b = Kalkulator(64, 29)
    c = Kalkulator(7, 9)
    d = Kalkulator(8, 0)
    e = Kalkulator(78, 4)
    f = Kalkulator(110, 2)
    A = np.array([[1, 52, 7, 10],
                  [4, 13, 24, 0],
                  [0, 12, 11, 3],
                  [31, 20, 1, 2]])
    B = np.array([[4, 63, 84, 10],
                  [0, 83, 59, 44],
                  [17, 96, 28, 4],
                  [71, 50, 32, 6]])
    g = Kalkulator(A, B)
    print(f"\nDziałania na liczbach")
    print(a.dodawanie(), b.odejmowanie(), c.mnozenie(), d.dzielenie(), e.potegowanie(), f.pierwiastkowanie(), sep='\n')
    print(f"\nDziałania na macierzach")
    print(g.dodawanie_macierzy(), g.odejmowanie_macierzy(), g.mnozenie_macierzy(), g.dzielenie_macierzy(),
          g.transpozycja_pierwszej_macierzy(), g.transpozycja_drugiej_macierzy(), sep='\n')

########################################################################################################################
##                                                     Zadanie 7                                                      ##
########################################################################################################################

from zadanie7_modul1 import MojaKlasa

if __name__ == '__main__':
    importowana_klasa = MojaKlasa(456, np.arange(10), np.inf)
    importowana_klasa.pokaz_typ_parametrow()
    importowana_klasa.dzikie_disco()
